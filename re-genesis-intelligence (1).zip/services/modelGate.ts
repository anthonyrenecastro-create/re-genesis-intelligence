// Model Gateway for Universal AI Engine Support
// Streamlined Architecture: Gemini (Multimodal + Google Search) & DeepSeek (Reasoning & Code) + Ollama (Local)
import { GoogleGenAI } from '@google/genai';
import type { ActiveEngine, GeminiHistory, AiSettings, SubstrateMode, CustomSubstrate, NewsItem, SubstrateVantage, EngineConfig } from '../types';

const cleanAndParseJson = (text: string) => {
    const sanitizedText = text.replace(/\[\d+\]/g, "");
    const start = sanitizedText.indexOf('[');
    if (start === -1) return null;
    let end = -1;
    const lastBrace = sanitizedText.lastIndexOf('}');
    if (lastBrace !== -1) {
        end = sanitizedText.indexOf(']', lastBrace);
    }
    if (end === -1) end = sanitizedText.lastIndexOf(']');
    if (end === -1 || end <= start) return null;
    let jsonStr = sanitizedText.substring(start, end + 1);
    jsonStr = jsonStr
        .replace(/}\s*{/g, '},{')
        .replace(/]\s*\[/g, '],[')
        .replace(/,\s*]/g, ']')
        .replace(/,\s*}/g, '}')
        .replace(/[\u0000-\u001F\u007F-\u009F]/g, "")
        .trim();
    try {
        return JSON.parse(jsonStr);
    } catch {
        try {
            return JSON.parse(jsonStr.replace(/(\w+):/g, '"$1":'));
        } catch {
            return null;
        }
    }
};

// Default fallback items when offline or prior to provisioning keys
const getCuratedSubstrateNews = (mode: SubstrateMode): NewsItem[] => {
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const defaults: Record<string, NewsItem[]> = {
        discover: [
            { id: '1', title: 'Multimodal Frontier Synchronization', summary: 'Gemini and DeepSeek unified telemetry stream active with real-time reasoning verification.', url: 'https://deepmind.google/technologies/gemini/', source: 'Cortex Feed', timestamp: now },
            { id: '2', title: 'SNN Syntropy Optimization', summary: 'Spiking neural network manifold stabilized at optimal coupling coefficients.', url: '#', source: 'Bio-SNN Core', timestamp: now },
            { id: '3', title: 'Google Search Grounding Link', summary: 'Live real-time web retrieval pipeline online for instantaneous world fact verification.', url: '#', source: 'Search Mesh', timestamp: now },
        ],
        finance: [
            { id: '1', title: 'Decentralized Liquidity Matrix', summary: 'Automated market making pools shifting toward zero-slippage invariant curves.', url: '#', source: 'DeFi Terminal', timestamp: now },
            { id: '2', title: 'Macro Yield Spread Compression', summary: 'Treasury curve re-steepening signals algorithmic risk-parity reallocation.', url: '#', source: 'Macro Pulse', timestamp: now },
        ],
        patents: [
            { id: '1', title: 'Neuromorphic Optical Chip Architecture', summary: 'New patent filings demonstrate sub-picosecond synaptic optical switching.', url: '#', source: 'USPTO Radar', timestamp: now },
        ],
        academic: [
            { id: '1', title: 'Non-equilibrium Thermodynamic Memory', summary: 'Preprint details reversible computation using microfluidic cellular automata.', url: '#', source: 'arXiv Quantum', timestamp: now },
        ]
    };
    return defaults[mode] || defaults.discover;
};

// Fetch substrate news using Gemini (Google Search Grounding) or DeepSeek
export const fetchSubstrateNews = async (
    mode: SubstrateMode, 
    keys: { geminiKey?: string; deepSeekKey?: string } | string, 
    vantage?: SubstrateVantage
): Promise<NewsItem[]> => {
    const geminiKey = typeof keys === 'string' ? keys : (keys?.geminiKey || '');
    const deepSeekKey = typeof keys === 'object' ? (keys?.deepSeekKey || '') : '';
    const vantageContext = vantage ? `Focus specifically on the "${vantage.label}" perspective.` : "";
    const prompt = `Retrieve exactly 5 critical, up-to-date developments regarding the "${mode}" substrate. ${vantageContext} Return ONLY a strictly valid JSON array of objects with keys: "id", "title", "summary", "url", "source", "timestamp".`;

    // 1. Try Gemini with Google Search Grounding (Superior live web retrieval)
    if (geminiKey && geminiKey.length > 5) {
        try {
            const ai = new GoogleGenAI({ apiKey: geminiKey });
            const response = await ai.models.generateContent({
                model: 'gemini-3.8-flash',
                contents: prompt,
                config: {
                    tools: [{ googleSearch: {} }],
                    temperature: 0.2,
                }
            });
            const text = response.text || '';
            const parsed = cleanAndParseJson(text);
            if (parsed && Array.isArray(parsed) && parsed.length > 0) return parsed;
        } catch (e) {
            console.warn("[Gemini News Grounding] Error:", e);
        }
    }

    // 2. Try DeepSeek if provided
    if (deepSeekKey && deepSeekKey.length > 5) {
        try {
            const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${deepSeekKey}`, 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model: 'deepseek-chat',
                    messages: [{ role: 'user', content: prompt }],
                    temperature: 0.2
                })
            });
            if (response.ok) {
                const data = await response.json();
                const content = data.choices?.[0]?.message?.content || '';
                const parsed = cleanAndParseJson(content);
                if (parsed && Array.isArray(parsed) && parsed.length > 0) return parsed;
            }
        } catch (e) {
            console.warn("[DeepSeek News] Error:", e);
        }
    }

    return getCuratedSubstrateNews(mode);
};

// Fetch substrate vantages using Gemini or DeepSeek
export const fetchSubstrateVantages = async (
    mode: SubstrateMode, 
    keys: { geminiKey?: string; deepSeekKey?: string } | string
): Promise<SubstrateVantage[]> => {
    const geminiKey = typeof keys === 'string' ? keys : (keys?.geminiKey || '');
    const deepSeekKey = typeof keys === 'object' ? (keys?.deepSeekKey || '') : '';
    const prompt = `Analyze the current technological landscape for the "${mode}" substrate. Identify 4 unique functional vantages. Return ONLY a strictly valid JSON array of objects with keys: "id", "label", "icon", "description", "instruction".`;

    if (geminiKey && geminiKey.length > 5) {
        try {
            const ai = new GoogleGenAI({ apiKey: geminiKey });
            const response = await ai.models.generateContent({
                model: 'gemini-3.8-flash',
                contents: prompt,
                config: { temperature: 0.4 }
            });
            const text = response.text || '';
            const parsed = cleanAndParseJson(text);
            if (parsed && Array.isArray(parsed) && parsed.length > 0) return parsed;
        } catch (e) {
            console.warn("[Gemini Vantages] Error:", e);
        }
    }

    if (deepSeekKey && deepSeekKey.length > 5) {
        try {
            const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${deepSeekKey}`, 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model: 'deepseek-chat',
                    messages: [{ role: 'user', content: prompt }],
                    temperature: 0.4
                })
            });
            if (response.ok) {
                const data = await response.json();
                const parsed = cleanAndParseJson(data.choices?.[0]?.message?.content || '');
                if (parsed && Array.isArray(parsed) && parsed.length > 0) return parsed;
            }
        } catch (e) {
            console.warn("[DeepSeek Vantages] Error:", e);
        }
    }

    return [
        { id: 'core', label: 'Primary Synthesis', icon: 'zap', description: 'Central algorithmic analysis', instruction: 'Evaluate from first principles.' },
        { id: 'macro', label: 'Macro Landscape', icon: 'globe', description: 'Broad ecosystem trends', instruction: 'Focus on global shifts and dependencies.' },
        { id: 'edge', label: 'Fringe Anomalies', icon: 'activity', description: 'Emerging edge dynamics', instruction: 'Detect anomalies and outliers.' },
        { id: 'pragmatic', label: 'Actionable Vector', icon: 'shield', description: 'Tactical implementation path', instruction: 'Extract immediate strategic next steps.' }
    ];
};

// Validate API key format
const validateApiKey = (engine: ActiveEngine, key: string): { valid: boolean; message?: string } => {
    if (!key || key.trim().length === 0) {
        return { valid: false, message: 'API key is empty' };
    }
    
    switch (engine) {
        case 'Gemini':
            if (key.length < 10) {
                return { valid: false, message: 'Gemini API key appears to be invalid' };
            }
            return { valid: true };
        case 'DeepSeek':
            if (!key.startsWith('sk-') && key.length < 15) {
                return { valid: false, message: 'DeepSeek API key usually starts with "sk-"' };
            }
            return { valid: true };
        default:
            return { valid: true };
    }
};

export const sendMessageToUniversalEngine = async (
    engine: ActiveEngine,
    message: string,
    history: GeminiHistory,
    settings: AiSettings,
    systemInstruction: string,
    engineConfigs: Record<ActiveEngine, EngineConfig>,
    mode: SubstrateMode = 'discover',
    customSubs: CustomSubstrate[] = [],
    activeVantage?: SubstrateVantage,
    inlineData?: { data: string, mimeType: string } | null
) => {
    let domainFocus = `MODE_ACTIVE: ${mode.toUpperCase()}. `;
    if (activeVantage) {
        domainFocus += `VANTAGE_LOCKED: ${activeVantage.label}. LOGIC_MESH: ${activeVantage.instruction}`;
    }

    const finalSystem = `${systemInstruction}\n\n[SUBSTRATE_ORCHESTRATION_CONTEXT]:\n${domainFocus}\nACTIVE_ENGINE: ${engine}`;

    async function* engineStream() {
        const key = engineConfigs[engine]?.apiKey;
        
        if ((!key || key.length < 5) && engine !== 'Ollama') {
            yield { text: `[MESH_DESYNC]: No valid API key provisioned for ${engine}. Please enter your ${engine} API key in System Settings.` };
            return;
        }
        
        if (engine !== 'Ollama') {
            const validation = validateApiKey(engine, key!);
            if (!validation.valid) {
                yield { text: `[API_KEY_ERROR]: ${engine} API key validation failed: ${validation.message}. Check your key in Settings.` };
                return;
            }
        }

        // ==========================================
        // 1. GEMINI ENGINE (Google AI Studio)
        // Multimodal, Google Search Grounding, Long Context
        // ==========================================
        if (engine === 'Gemini') {
            try {
                const ai = new GoogleGenAI({ apiKey: key! });
                
                // Format conversation history
                const contents: any[] = [];
                for (const h of history) {
                    const parts: any[] = [];
                    for (const p of h.parts) {
                        if (p.inlineData) {
                            parts.push({ inlineData: p.inlineData });
                        }
                        if (p.text) {
                            parts.push({ text: p.text });
                        }
                    }
                    if (parts.length > 0) {
                        contents.push({
                            role: h.role === 'model' ? 'model' : 'user',
                            parts
                        });
                    }
                }

                // Add current user prompt + inlineData (e.g. image/document)
                const currentParts: any[] = [];
                if (inlineData) {
                    currentParts.push({ inlineData });
                }
                currentParts.push({ text: message });
                contents.push({ role: 'user', parts: currentParts });

                const responseStream = await ai.models.generateContentStream({
                    model: 'gemini-3.8-flash',
                    contents,
                    config: {
                        systemInstruction: finalSystem,
                        temperature: settings.temperature,
                        maxOutputTokens: settings.maxOutputTokens || 2048,
                        tools: [{ googleSearch: {} }] // Real-time web search grounding!
                    }
                });

                let accumulatedText = '';
                for await (const chunk of responseStream) {
                    const chunkText = chunk.text || '';
                    if (chunkText) {
                        accumulatedText += chunkText;
                        yield { text: accumulatedText };
                    }
                }
                return;
            } catch (err: any) {
                console.error("[Gemini] Stream error:", err);
                yield { text: `[GEMINI_FAULT]: ${err?.message || 'Failed to communicate with Gemini.'}` };
                return;
            }
        }

        // ==========================================
        // 2. DEEPSEEK ENGINE (DeepSeek API)
        // Deep Chain-of-Thought Reasoning & Code
        // ==========================================
        if (engine === 'DeepSeek') {
            try {
                const endpoint = 'https://api.deepseek.com/v1/chat/completions';
                const body = {
                    model: 'deepseek-reasoner', // DeepSeek R1 reasoning model
                    messages: [
                        { role: 'system', content: finalSystem },
                        ...history.map(h => ({
                            role: h.role === 'model' ? 'assistant' : 'user',
                            content: h.parts[0]?.text || ''
                        })),
                        { role: 'user', content: message }
                    ],
                    temperature: settings.temperature,
                    max_tokens: settings.maxOutputTokens || 2048,
                    stream: false
                };

                const response = await fetch(endpoint, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${key}`
                    },
                    body: JSON.stringify(body)
                });

                if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error(`DeepSeek API error (${response.status}): ${errorText}`);
                }

                const result = await response.json();
                const text = result.choices?.[0]?.message?.content || '';
                const thinking = result.choices?.[0]?.message?.reasoning_content || '';

                if (!text && !thinking) throw new Error("DeepSeek returned an empty response.");
                yield { text, thinking };
                return;
            } catch (err: any) {
                console.error("[DeepSeek] Error:", err);
                yield { text: `[DEEPSEEK_FAULT]: ${err?.message || 'Failed to connect to DeepSeek.'}` };
                return;
            }
        }

        // ==========================================
        // 3. OLLAMA ENGINE (Local Offline Instance)
        // ==========================================
        if (engine === 'Ollama') {
            try {
                const endpoint = `${key || 'http://localhost:11434'}/api/chat`;
                const body = {
                    model: 'llama3',
                    messages: [
                        { role: 'system', content: finalSystem },
                        ...history.map(h => ({
                            role: h.role === 'model' ? 'assistant' : 'user',
                            content: h.parts[0]?.text || ''
                        })),
                        { role: 'user', content: message }
                    ],
                    stream: false
                };

                const response = await fetch(endpoint, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body)
                });

                if (!response.ok) {
                    throw new Error(`Ollama error (${response.status})`);
                }

                const result = await response.json();
                const text = result.message?.content || '';
                if (!text) throw new Error("Ollama returned an empty response.");
                yield { text };
                return;
            } catch (err: any) {
                console.error("[Ollama] Error:", err);
                yield { text: `[OLLAMA_FAULT]: Ensure Ollama is running locally at http://localhost:11434 with 'ollama run llama3'.` };
                return;
            }
        }
    }

    return engineStream();
};
